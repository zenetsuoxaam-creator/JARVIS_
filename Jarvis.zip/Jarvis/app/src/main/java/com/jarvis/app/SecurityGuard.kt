package com.jarvis.app

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Debug
import android.view.WindowManager
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

/**
 * Sirf OWNER ki suraksha ke liye (is phone par):
 *  - App Lock: Jarvis kholne se pehle phone ka screen-lock (PIN / pattern / fingerprint) maanga jaata hai.
 *  - FLAG_SECURE: screenshot / screen-record / recent-apps preview mein API keys aur chat nahi dikhte.
 *  - Integrity check: app ka signing certificate pehli baar yaad rakhta hai; badalne par ya debugger judne par warning.
 *  - Security log: kab, kya hua (galat unlock, tamper warning) sirf is phone mein, owner ko settings mein dikhta hai.
 * Ye kisi ki location, naam ya number nahi nikalta.
 */
object SecurityGuard {
    const val REQ_UNLOCK = 4242
    private const val P = "jarvis_security"
    @Volatile private var unlockedAt = 0L
    private const val GRACE_MS = 2 * 60 * 1000L   // 2 minute tak dobara nahi poochta

    private fun sp(c: Context) = c.getSharedPreferences(P, Context.MODE_PRIVATE)

    fun lockEnabled(c: Context) = sp(c).getBoolean("lock", true)
    fun setLock(c: Context, on: Boolean) = sp(c).edit().putBoolean("lock", on).apply()

    fun protectWindow(a: Activity) {
        a.window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
    }

    private fun certHash(c: Context): String? = try {
        val pm = c.packageManager
        val sigs = if (Build.VERSION.SDK_INT >= 28) {
            val i = pm.getPackageInfo(c.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            i.signingInfo?.apkContentsSigners
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(c.packageName, PackageManager.GET_SIGNATURES).signatures
        }
        sigs?.firstOrNull()?.let { MessageDigest.getInstance("SHA-256").digest(it.toByteArray()).joinToString("") { b -> "%02x".format(b) } }
    } catch (_: Exception) { null }

    /** Tamper ki wajah (ya null agar sab theek). */
    fun integrityProblem(c: Context): String? {
        val h = certHash(c) ?: return null
        val saved = sp(c).getString("cert", null)
        if (saved == null) { sp(c).edit().putString("cert", h).apply() }
        else if (saved != h) return "App ka signing certificate badal gaya hai"
        if (Debug.isDebuggerConnected()) return "Debugger juda hua hai"
        return null
    }

    fun log(c: Context, event: String) {
        val arr = try { JSONArray(sp(c).getString("log", "[]")) } catch (_: Exception) { JSONArray() }
        arr.put(JSONObject().put("t", System.currentTimeMillis()).put("e", event).put("dev", "${Build.MANUFACTURER} ${Build.MODEL}"))
        val trimmed = JSONArray()
        for (i in maxOf(0, arr.length() - 50) until arr.length()) trimmed.put(arr.get(i))
        sp(c).edit().putString("log", trimmed.toString()).apply()
    }

    fun logText(c: Context): String {
        val arr = try { JSONArray(sp(c).getString("log", "[]")) } catch (_: Exception) { JSONArray() }
        if (arr.length() == 0) return "Abhi tak koi security event nahi."
        val f = java.text.SimpleDateFormat("dd MMM HH:mm", java.util.Locale.getDefault())
        return (arr.length() - 1 downTo maxOf(0, arr.length() - 15)).joinToString("\n") {
            val o = arr.getJSONObject(it); "${f.format(java.util.Date(o.getLong("t")))}  •  ${o.getString("e")}"
        }
    }

    /** Lock chahiye to unlock screen kholta hai. true = abhi kholne ki zaroorat padi. */
    fun requireUnlock(a: Activity): Boolean {
        if (!lockEnabled(a)) return false
        if (System.currentTimeMillis() - unlockedAt < GRACE_MS) return false
        val km = a.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isDeviceSecure) return false   // phone mein screen-lock hi nahi to kuch nahi kar sakte
        val i: Intent = km.createConfirmDeviceCredentialIntent("JARVIS", "Apna PIN / pattern / fingerprint daalo") ?: return false
        a.startActivityForResult(i, REQ_UNLOCK)
        return true
    }

    fun onUnlockResult(a: Activity, ok: Boolean) {
        if (ok) unlockedAt = System.currentTimeMillis()
        else { log(a, "Galat / cancel unlock try"); a.finishAffinity() }
    }
}
