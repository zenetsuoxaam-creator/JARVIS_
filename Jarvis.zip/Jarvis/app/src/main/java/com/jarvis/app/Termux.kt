package com.jarvis.app

import android.content.Context
import android.content.Intent

/**
 * Termux mein command chalata hai (Termux ke RUN_COMMAND intent se).
 * Setup: Termux mein ~/.termux/termux.properties mein  allow-external-apps=true  likho, phir Termux restart karo.
 * JARVIS kabhi khud command nahi chalata. Har command pehle user ki 'haan' se hi jaati hai.
 */
object Termux {
    private const val BASH = "/data/data/com.termux/files/usr/bin/bash"
    private const val HOME = "/data/data/com.termux/files/home"

    fun run(ctx: Context, cmd: String): String = try {
        ctx.startService(Intent("com.termux.RUN_COMMAND")
            .setClassName("com.termux", "com.termux.app.RunCommandService")
            .putExtra("com.termux.RUN_COMMAND_PATH", BASH)
            .putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", cmd))
            .putExtra("com.termux.RUN_COMMAND_WORKDIR", HOME)
            .putExtra("com.termux.RUN_COMMAND_BACKGROUND", false))
        "Termux mein command chala di. Output Termux mein dikhega."
    } catch (e: Exception) {
        "Termux nahi chala: ${e.message}. Termux mein allow-external-apps=true set karo aur permission do."
    }
}
