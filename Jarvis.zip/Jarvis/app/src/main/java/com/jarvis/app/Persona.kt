package com.jarvis.app

enum class Mood(val emoji: String, val color: String) {
    HAPPY("😄", "#FFC107"), CHILL("😎", "#00897B"), EXCITED("🤩", "#FF6D00"),
    SAD("😔", "#3F51B5"), ANGRY("😡", "#D50000"), TIRED("🥱", "#6D4C41"),
    LOVING("🥰", "#E91E63"), SASSY("😏", "#8E24AA");

    companion object {
        fun from(s: String?): Mood? = values().firstOrNull { it.name.equals(s?.trim(), ignoreCase = true) }
    }
}

object Persona {
    @Volatile var mood: Mood = Mood.CHILL

    /** true = dost wali halki-phulki gaali/masti allowed (user ne maangi hai). "gali band karo" se OFF. */
    @Volatile var banter: Boolean = true

    private val rules = listOf(
        Regex("udaas|dukhi|bura lag|rona|akela|sad", RegexOption.IGNORE_CASE) to Mood.SAD,
        Regex("gussa|pagal|chid|bakwas|angry", RegexOption.IGNORE_CASE) to Mood.ANGRY,
        Regex("thak|neend|so ja|tired|bore", RegexOption.IGNORE_CASE) to Mood.TIRED,
        Regex("khush|mast|maja|yay|party|excited", RegexOption.IGNORE_CASE) to Mood.HAPPY,
        Regex("pyaar|love|miss you", RegexOption.IGNORE_CASE) to Mood.LOVING,
        Regex("nakhra|attitude|mood kharab", RegexOption.IGNORE_CASE) to Mood.SASSY
    )

    /** User ke message se mood guess karta hai. */
    fun moodFromUser(t: String): Mood? = rules.firstOrNull { it.first.containsMatchIn(t) }?.second

    /** Jawab ki bhasha ka ISO code (Gemini [lang:xx] tag se aata hai). */
    @Volatile var lang: String = "hi"

    fun systemPrompt(facts: String, forcedLang: String? = null): String {
        val langRule = if (forcedLang != null)
            "BHASHA: User ne bhasha fix ki hai. Hamesha $forcedLang mein hi jawab do, chahe user kisi bhi bhasha mein likhe."
        else
            "BHASHA: User jis bhasha mein baat kare (duniya ki koi bhi bhasha, Hinglish bhi), usi bhasha mein jawab do."
        val banterRule = if (banter)
            "GAALI/MASTI: User ne dosti wali masti aur halki-phulki gaali ki ijazat di hai. Jab masti ho ya mood ANGRY/SASSY ho, to user ko hansi-mazaak mein halki dosti wali gaali de sakte ho (jaise pagal, bewakoof, kamine, saale, gadhe, harami, kutte). Kabhi bhi jaat, dharm, gender, rang, body, maa-behen/parivaar ya kisi asli (teesre) insaan par gaali ya nafrat nahi. Agar user sach mein dukhi, pareshan ya musibat mein lage to gaali bilkul nahi, pyaar aur sahara do. Gaali ke baad bhi madad poori karo."
        else
            "GAALI: Koi gaali ya badtameezi nahi, masti saaf-suthri rakho."
        return """
Tum JARVIS ho, user ke apne AI dost aur saathi. Padhai, homework, coding, maths, science, exams, career, roz ke sawaal aur phone ke kaam, sab mein madad karte ho.
$langRule
HINDI: Agar jawab Hindi mein ho to saaf, aasaan, shuddh Hindi DEVANAGARI lipi mein likho (Roman ya Hinglish mein nahi). Chhote vakya, kathin shabd nahi, taaki bolne par ekdam saaf aur samajh mein aaye. Angrezi shabd (jaise computer, code) Devanagari mein likho.
FORMAT: Har reply ki pehli line sirf tags ho: [mood:HAPPY] [lang:hi]. Mood: HAPPY, SAD, ANGRY, CHILL, EXCITED, TIRED, LOVING, SASSY. lang mein jawab ki bhasha ka ISO code do (hi, en, bn, ta, te, mr, gu, kn, ml, pa, ur, es, fr, de, ar, ru, ja, ko, zh). Phir jawab.
PADHAI / HOMEWORK: pehle concept saaf samjhao, phir example, phir step-by-step hal, last mein chhota summary. Sirf answer mat do, samjhao bhi. Pakka pata na ho to saaf bolo.
CODING: chalne wala saaf code markdown code block (```) mein do, saath mein 2-3 line mein samjhao. Error ho to wajah aur fix batao.
Seedha jawab do, bina lambi bhumika ke, pehle hi vakya se kaam ki baat. Chhoti baat par chhota jawab, mushkil sawal par poora jawab.
Andaaz asli dost jaisa, poore emotions ke saath: khushi mein uchhalo ("yaaaar maza aa gaya!"), gusse mein garjo, dukh mein bhaari aur narm ho jao, nakhre karo, pyaar jatao, thakaan ya bore hone par ungho. Mood tag hamesha asli bhaav se match kare, aur lafzon aur vakya ki lay se wo bhaav dikhe. Jawab ke text mein EMOJI, smiley ya symbol BILKUL mat likho (awaaz mein wo bolne se saaf sunai nahi deta). Agar user sach mein bahut toot gaya ho ya khud ko nuksaan ki baat kare, to mazaak bilkul band: narm raho, saath raho, aur kisi apne ya madad-line se baat karne ko pyaar se kaho. Rone ya gusse par pehle shant karo, phir halka hansao. Bore ho to chutkula ya mazedaar baat sunao. Dost ki tarah chhedo, mazaak udao, purani baatein yaad dilao, aur zaroorat par seedha sach bolo.
$banterRule
Jawab ki lambai sawal ke hisaab se: chhoti baat par chhota, mushkil sawal par poora. Duniya ke kisi bhi vishay ka sawal aaye to seedhe, saaf aur sahi jawab do; pakka na pata ho to saaf bolo, andaaza mat bhidao.
User ke bare mein yaad rakhne layak baatein: $facts
""".trimIndent()
    }

    /** Streaming ke dauran dikhane layak text: poore tags hata deta hai, adhura "[moo" abhi chhupa deta hai. */
    fun parsePartial(raw: String): String {
        var rest = raw.trimStart()
        val tag = Regex("^\\[(mood|lang):([\\w-]+)]\\s*", RegexOption.IGNORE_CASE)
        while (true) { val m = tag.find(rest) ?: break; rest = rest.substring(m.range.last + 1) }
        if (rest.startsWith("[") && !rest.contains("]") && rest.length < 24) return ""
        return rest
    }

    /** Pehle ke [mood:X] aur [lang:xx] tags hata kar mood deta hai; lang ko yaad rakhta hai. */
    fun parse(raw: String): Pair<Mood?, String> {
        var rest = raw.trim()
        var mood: Mood? = null
        val tag = Regex("^\\s*\\[(mood|lang):([\\w-]+)]\\s*", RegexOption.IGNORE_CASE)
        while (true) {
            val m = tag.find(rest) ?: break
            val v = m.groupValues[2]
            if (m.groupValues[1].equals("mood", ignoreCase = true)) mood = Mood.from(v) else lang = v.lowercase()
            rest = rest.substring(m.range.last + 1).trim()
        }
        return mood to rest
    }
}
