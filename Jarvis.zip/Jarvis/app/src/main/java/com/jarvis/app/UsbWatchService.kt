package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import androidx.core.content.ContextCompat

/**
 * USB cable juda to "Cast" notification dikhata hai. Notification par tap = phone ke Cast screen khulta hai,
 * jahan se TV / Chromecast / Miracast device chun kar screen cast hoti hai.
 * Settings mein "USB cast notification" ON hone par hi chalta hai.
 */
class UsbWatchService : Service() {

    companion object {
        private const val CH_WATCH = "jarvis_usb_watch"
        private const val CH_OFFER = "jarvis_usb_offer"
        private const val ID_WATCH = 2
        private const val ID_OFFER = 3
        private const val USB_STATE = "android.hardware.usb.action.USB_STATE"

        fun start(ctx: Context) {
            val i = Intent(ctx, UsbWatchService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, UsbWatchService::class.java)) }
    }

    private var lastConnected = false

    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action != USB_STATE) return
            val connected = i.getBooleanExtra("connected", false)
            if (connected && !lastConnected) offerCast(c)
            if (!connected) c.getSystemService(NotificationManager::class.java).cancel(ID_OFFER)
            lastConnected = connected
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_WATCH, "JARVIS USB watch", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel(CH_OFFER, "USB cast", NotificationManager.IMPORTANCE_HIGH))
        val n: Notification = Notification.Builder(this, CH_WATCH)
            .setContentTitle("JARVIS: USB cast ON")
            .setContentText("USB juda to cast ka notification aayega")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(ID_WATCH, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(ID_WATCH, n)
        ContextCompat.registerReceiver(this, rcv, IntentFilter(USB_STATE), ContextCompat.RECEIVER_EXPORTED)
    }

    private fun offerCast(c: Context) {
        val cast = Intent(Settings.ACTION_CAST_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(c, 1, cast, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(c, CH_OFFER)
            .setContentTitle("USB se device juda hai")
            .setContentText("Tap karo: phone ki screen cast karo")
            .setStyle(Notification.BigTextStyle().bigText(
                "Tap karo aur list se TV / Chromecast / wireless display chuno, phone ki screen wahan cast ho jayegi. " +
                "Laptop/PC par USB se screen dekhne ke liye scrcpy use karo. " +
                "TV/computer/phone ko control karne ke liye Bluetooth se pair karo aur Jarvis ko bolo: \"jo device connected hai use control karo\"."))
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        c.getSystemService(NotificationManager::class.java).notify(ID_OFFER, n)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try { unregisterReceiver(rcv) } catch (_: Exception) { }
        super.onDestroy()
    }
}
