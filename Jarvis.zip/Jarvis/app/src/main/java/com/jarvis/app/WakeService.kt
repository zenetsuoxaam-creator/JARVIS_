package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale
import java.util.concurrent.Executors

/**
 * "Jarvis" bolne par jagne wali service. Foreground service hai, isliye notification dikhti hai.
 * Note: ye battery use karti hai, aur on-device recognizer ki quality phone par depend karti hai.
 */
class WakeService : Service(), TextToSpeech.OnInitListener {
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var sr: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var running = false
    private val wakeRegex = Regex("jarvis|जार्विस|जारविस", RegexOption.IGNORE_CASE)

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        val chId = "jarvis_wake"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(chId, "JARVIS", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, chId)
            .setContentTitle("JARVIS sun raha hai")
            .setContentText("Bolo: \"Jarvis ...\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!running) { running = true; main.post { listen() } }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS && tts.setLanguage(Locale("hi", "IN")) < 0) tts.language = Locale.US
    }

    /** Ek baar sunta hai, result aane par phir se sunna shuru. */
    private fun listen() {
        if (!running) return
        sr?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                handleSpeech(t)
                main.postDelayed({ listen() }, 300)
            }
            override fun onError(error: Int) { main.postDelayed({ listen() }, 1000) }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Lang.sttTag(this@WakeService))
        })
    }

    private fun handleSpeech(t: String) {
        val m = wakeRegex.find(t) ?: return
        val cmd = t.substring(m.range.last + 1).trim()
        io.execute {
            val reply = if (cmd.isEmpty()) Reply("Haan bhai, bol!", Mood.CHILL)
                        else CommandRouter.process(this, cmd)
            main.post {
                try { tts.language = Lang.locale(Lang.speakLang(this)) } catch (_: Exception) { }
                tts.speak(Lang.cleanForSpeech(reply.text), TextToSpeech.QUEUE_FLUSH, null, "wake")
            }
        }
    }

    override fun onDestroy() {
        running = false
        sr?.destroy()
        tts.shutdown()
        io.shutdown()
        super.onDestroy()
    }
}
