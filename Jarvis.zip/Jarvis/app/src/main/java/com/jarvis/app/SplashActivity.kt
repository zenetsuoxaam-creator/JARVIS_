package com.jarvis.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import kotlin.math.PI
import kotlin.math.sin

/**
 * App kholte hi animation (dark theme, app ke saath match):
 * glow ke saath vortex andar se aata hai aur ghoomte hue ruk jaata hai, 2 shockwave rings phailti hain,
 * "J A R V I S" akshar-akshar karke aata hai, phir smoothly home par fade.
 * Awaaz: Fx.openChime() (narm teen-note chime).
 */
class SplashActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0B0B0F")
        window.navigationBarColor = Color.parseColor("#0B0B0F")
        Fx.openChime()
        val v = SplashView(this)
        v.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        setContentView(v)
        ui.postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, TOTAL_MS)
    }

    override fun onDestroy() { ui.removeCallbacksAndMessages(null); super.onDestroy() }

    companion object { const val TOTAL_MS = 3400L }
}

private class SplashView(ctx: Context) : View(ctx) {
    private val bmp = BitmapFactory.decodeResource(ctx.resources, R.drawable.logo_vortex)
    private val img = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fade = Paint().apply { color = Color.parseColor("#0B0B0F") }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#ECECF1"); textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val t0 = System.currentTimeMillis()

    private fun clamp01(x: Float) = x.coerceIn(0f, 1f)
    private fun easeOut(x: Float): Float { val c = clamp01(x); return 1f - (1f - c) * (1f - c) * (1f - c) }
    private fun easeInOut(x: Float): Float { val c = clamp01(x); return c * c * (3f - 2f * c) }
    /** halka overshoot: andar se aakar thoda bada hoke settle hota hai */
    private fun back(x: Float): Float { val c = clamp01(x) - 1f; val s = 1.5f; return c * c * ((s + 1f) * c + s) + 1f }

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.parseColor("#0B0B0F"))
        val t = (System.currentTimeMillis() - t0) / 1000f
        val cx = width / 2f
        val cy = height * 0.42f
        val size = minOf(width, height) * 0.82f

        // peeche halka neela-baingani glow (saans lete hue)
        val pulse = 0.85f + 0.15f * sin(t * 2f * PI.toFloat())
        val ga = (200 * easeOut(t / 1.0f) * pulse).toInt()
        glow.shader = RadialGradient(cx, cy, size * 0.62f,
            intArrayOf(Color.argb(ga, 120, 70, 255), Color.argb(ga / 3, 40, 40, 160), Color.TRANSPARENT),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, size * 0.62f, glow)

        // vortex: tez ghoomta hua chhota se bada, phir dheere ghoomta rehta hai
        val scale = 0.25f + 0.75f * back(t / 1.3f)
        val spin = (1f - easeOut(t / 2.4f)) * 540f + t * 10f
        img.alpha = (255 * easeOut(t / 0.7f)).toInt()
        c.save()
        c.translate(cx, cy); c.rotate(spin); c.scale(scale * size / bmp.width, scale * size / bmp.height)
        c.drawBitmap(bmp, -bmp.width / 2f, -bmp.height / 2f, img)
        c.restore()

        // do shockwave rings
        for (k in 0..1) {
            val p = (t - 0.35f - k * 0.3f) / 1.4f
            if (p in 0f..1f) {
                ring.strokeWidth = size * 0.012f * (1f - p)
                ring.color = Color.argb((190 * (1f - p)).toInt(), 150, 120, 255)
                c.drawCircle(cx, cy, size * (0.15f + 0.55f * easeOut(p)), ring)
            }
        }

        // naam: akshar-akshar karke
        val name = "JARVIS"
        text.textSize = size * 0.095f
        text.letterSpacing = 0.32f
        val shown = clamp01((t - 1.3f) / 0.9f) * name.length
        val full = shown.toInt()
        val part = shown - full
        val ty = cy + size * 0.64f
        if (shown > 0f) {
            text.alpha = 255
            val partial = name.substring(0, minOf(full, name.length))
            c.drawText(partial, cx, ty, text)
            if (full < name.length) {
                text.alpha = (255 * part).toInt()
                c.drawText(name.substring(0, full + 1), cx, ty, text)
            }
        }

        // aakhir mein smooth fade
        if (t > 2.6f) {
            fade.alpha = (255 * easeInOut((t - 2.6f) / 0.8f)).toInt()
            c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fade)
        }
        postInvalidateOnAnimation()
    }
}
