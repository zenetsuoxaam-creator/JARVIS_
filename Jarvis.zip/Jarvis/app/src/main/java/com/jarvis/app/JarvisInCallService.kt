package com.jarvis.app

import android.content.Intent
import android.telecom.Call
import android.telecom.InCallService
import android.telecom.VideoProfile

/** Default-dialer call bridge. Calls are never answered automatically. */
class JarvisInCallService : InCallService() {
    companion object {
        @Volatile var currentCall: Call? = null
            private set
        @Volatile var service: JarvisInCallService? = null
            private set
    }

    override fun onCreate() {
        super.onCreate()
        service = this
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        currentCall = call
        call.registerCallback(object : Call.Callback() {
            override fun onStateChanged(c: Call, state: Int) {
                if (state == Call.STATE_ACTIVE) {
                    try { this@JarvisInCallService.setAudioRoute(CallAudioState.ROUTE_SPEAKER) } catch (_: Exception) { }
                }
                if (state == Call.STATE_DISCONNECTED) currentCall = null
            }
        })
        if (call.state == Call.STATE_RINGING) {
            val launch = Intent(this, CallConsentActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            try { startActivity(launch) } catch (_: Exception) { }
        }
    }

    override fun onCallRemoved(call: Call) {
        if (currentCall === call) currentCall = null
        super.onCallRemoved(call)
    }

    fun answerWithSpeaker(): Boolean {
        val call = currentCall ?: return false
        if (call.state != Call.STATE_RINGING) return false
        call.answer(VideoProfile.STATE_AUDIO_ONLY)
        setAudioRoute(CallAudioState.ROUTE_SPEAKER)
        return true
    }

    fun decline(): Boolean {
        val call = currentCall ?: return false
        if (call.state != Call.STATE_RINGING) return false
        call.reject(false, "")
        return true
    }

    fun hangUp(): Boolean {
        val call = currentCall ?: return false
        call.disconnect()
        return true
    }

    override fun onDestroy() {
        if (service === this) service = null
        super.onDestroy()
    }
}
