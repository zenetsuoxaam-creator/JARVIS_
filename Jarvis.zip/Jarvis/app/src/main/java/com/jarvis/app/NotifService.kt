package com.jarvis.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Notifications padhta hai. Smart reading ON ho to WhatsApp/Instagram/SMS/Telegram ke
 * naye message ko Gemini se analyse karke bolta hai (kisne bheja, kya bola, opinion, reply options).
 * Ye sirf BATATA hai, khud se kuch bhejta nahi. Bhejne ke liye user ki 'haan' chahiye.
 */
class NotifService : NotificationListenerService(), TextToSpeech.OnInitListener {
    companion object {
        val recent = ArrayList<String>()
        @Volatile var lastSender = ""
        @Volatile var lastPkg = ""
        private val watched = mapOf(
            "com.whatsapp" to "WhatsApp",
            "com.instagram.android" to "Instagram",
            "com.google.android.apps.messaging" to "SMS",
            "org.telegram.messenger" to "Telegram"
        )
        fun latest(n: Int = 5): List<String> = synchronized(recent) { recent.take(n) }
    }

    private val io = Executors.newSingleThreadExecutor()
    private var tts: TextToSpeech? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.setLanguage(Locale("hi", "IN"))
    }

    override fun onDestroy() {
        tts?.shutdown()
        io.shutdown()
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val e = sbn.notification.extras
        val title = e.getCharSequence("android.title")?.toString() ?: ""
        val text = e.getCharSequence("android.text")?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return

        synchronized(recent) {
            recent.add(0, "${sbn.packageName}: $title - $text")
            while (recent.size > 20) recent.removeAt(recent.size - 1)
        }

        val app = watched[sbn.packageName] ?: return
        if (!getSharedPreferences("jarvis", MODE_PRIVATE).getBoolean("smart_read", false)) return
        lastSender = title
        lastPkg = sbn.packageName
        io.execute {
            val r = CommandRouter.analyzeMessage(this, app, title, text)
            tts?.speak(r.text, TextToSpeech.QUEUE_ADD, null, "notif")
        }
    }
}
