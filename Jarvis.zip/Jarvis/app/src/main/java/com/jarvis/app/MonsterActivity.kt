package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

/**
 * Monster (vision core) page.
 *  - Kone mein chhota camera preview; khula haath = ghumao, ungli+angutha = zoom.
 *  - Haath ki MUTthi (fist) = monster CRUSH (haath kholo to wapas phoolta hai). Band karne ke liye ✕ dabao.
 *  - "monster band karo" bolne par, screen off hone par, ya JARVIS band hone par bhi band hota hai.
 */
class MonsterActivity : Activity() {

    companion object {
        @Volatile var instance: MonsterActivity? = null
        private const val REQ_CAM = 21
    }

    private lateinit var wv: WebView
    private var pendingCam: PermissionRequest? = null

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { finish() }
    }

    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
        Fx.openChime()
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        registerReceiver(screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF))

        wv = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            addJavascriptInterface(Bridge(), "JarvisBridge")
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? =
                    request?.url?.let { assetLoader.shouldInterceptRequest(it) }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) { handleCam(request) }
            }
            loadUrl("https://appassets.androidplatform.net/assets/monster.html")
        }
        setContentView(wv)
    }

    /** monster.html ke JavaScript se call hota hai: JarvisBridge.close() */
    inner class Bridge {
        @JavascriptInterface
        fun close() {
            runOnUiThread { finish() }
        }
    }

    /** MainActivity / CommandRouter se monster ko state bhejo (speaking, listening, idle) */
    fun pushState(state: String, text: String = "") {
        wv.evaluateJavascript(
            "window.jarvisSetState && window.jarvisSetState(${JSONObject.quote(state)}, ${JSONObject.quote(text)});",
            null
        )
    }

    private fun handleCam(req: PermissionRequest) {
        if (!req.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) { req.deny(); return }
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            req.grant(req.resources)
        } else {
            pendingCam = req
            requestPermissions(arrayOf(Manifest.permission.CAMERA), REQ_CAM)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_CAM) {
            val r = pendingCam ?: return
            pendingCam = null
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) r.grant(r.resources)
            else r.deny()
        }
    }

    override fun onDestroy() {
        instance = null
        try { unregisterReceiver(screenOff) } catch (e: Exception) { }
        super.onDestroy()
    }
}
