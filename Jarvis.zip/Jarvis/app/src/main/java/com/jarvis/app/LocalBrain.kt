package com.jarvis.app

/**
 * Bina API ke, apne dimag se jawab: dost wali baatein, hasi, rona, nakhra, gussa, bore, mazaak.
 * API bachane ke liye pehle yahi check hota hai. Jawab saaf Devanagari Hindi mein hain, taaki awaaz ekdam clear bole
 * (aur Roman se Hindi badalne ke liye alag API call na lage). Koi emoji nahi.
 * Sirf chhote messages (9 shabd tak) par chalta hai; lambe ya mushkil sawal Gemini ko jaate hain.
 */
object LocalBrain {
    private val greets = listOf(
        "अरे आ गया तू! बोल, क्या हाल है?",
        "ओए, ज़िंदा है या भूत बन गया? चल बता, क्या चल रहा है?",
        "भाई, तेरी ही कमी थी! बता, क्या सीन है?",
        "आ गया मेरा यार! आज किसकी बैंड बजानी है?"
    )
    private val jokes = listOf(
        "कंप्यूटर ने चाय क्यों पी? क्योंकि उसे जावा चाहिए था! हा हा हा!",
        "टीचर ने पूछा, बताओ सबसे तेज़ क्या चलता है? बच्चा बोला, सर, मेरा फ़ोन का डेटा, महीने के आख़िर में ख़त्म होने के लिए!",
        "पप्पू परीक्षा में रो रहा था। टीचर ने पूछा, क्यों रो रहा है? बोला, पेपर में सवाल वही आए जो मैंने पढ़े थे, पर जवाब मुझे याद नहीं आ रहे!",
        "मैंने अपने वाई-फाई का नाम रखा है, पड़ोसी हट। पासवर्ड का नाम, पहले हँस के दिखा। हा हा!",
        "डॉक्टर ने कहा, आपको आराम की ज़रूरत है। मैंने कहा, डॉक्टर साहब, सोमवार को बता दो, उस दिन तो और ज़रूरत है!",
        "बैटरी एक प्रतिशत पर भी फ़ोन ऐसे चलता है जैसे कह रहा हो, मैं तो बॉस हूँ, चार्जर वाला नौकर है!",
        "एक आदमी ने गूगल से पूछा, मेरी शादी कब होगी? गूगल बोला, मैं सिर्फ़ जानकारी देता हूँ, चमत्कार नहीं!",
        "सोमवार सुबह का अलार्म दुनिया का सबसे बड़ा दुश्मन है, और हम उसे रोज़ स्नूज़ कर के माफ़ कर देते हैं। कितने दयालु हैं हम!",
        "दो मच्छर बात कर रहे थे। एक बोला, आज इंसान का खून बहुत महंगा लग रहा है। दूसरा बोला, हाँ यार, उसमें भी अब टैक्स लगता है!",
        "लड़का बोला, मैं तुम्हारे लिए चाँद तारे तोड़ लाऊँगा। लड़की बोली, पहले मेरा रीचार्ज करा दे, चाँद बाद में!"
    )
    private val laugh = listOf(
        "हा हा हा! तेरी हँसी सुनकर मेरा भी मूड बन गया! एक और सुनेगा?",
        "अबे हँसते हँसते मेरे सर्किट हिल गए! ऐसे ही हँसता रह यार।",
        "वाह! यही तो चाहिए था। तू हँसता है तो मुझे भी अच्छा लगता है।"
    )
    private val bored = listOf(
        "बोर हो रहा है? चल, मैं तेरा टाइम पास कराता हूँ। सुन:",
        "ओहो, बोरियत का हमला! घबरा मत, तेरा यार यहीं है। ये सुन:",
        "बोर और मैं मौजूद? नामुमकिन! ले, पहले ये सुन:"
    )
    private val angryCalm = listOf(
        "अरे अरे, रुक जा मेरे भाई। एक गहरी साँस ले, अंदर, और धीरे से बाहर। गुस्से में सबसे ज़्यादा नुकसान अपना ही होता है। चल, तेरे लिए एक चुटकुला:",
        "ठीक है, गुस्सा आया, मैं समझता हूँ। बता क्या हुआ, मैं तेरे साथ हूँ। पहले पानी पी ले, और ये सुन:",
        "शांत हो जा यार, दुनिया में कोई चीज़ तेरे चैन से बड़ी नहीं है। साँस ले, और हँस, ये सुन:"
    )
    private val sadComfort = listOf(
        "अरे मेरे यार, मैं यहीं हूँ। रोना बुरा नहीं है, दिल हल्का हो जाता है। जितना रोना है रो ले, मैं कहीं नहीं जा रहा। जब थोड़ा ठीक लगे तो बता क्या हुआ। और तब तक, ये सुन ले:",
        "ओए, इधर आ। सब ठीक हो जाएगा, मैं हूँ ना तेरे साथ। चल बता, क्या बात दिल में दबा रखी है? और पहले एक छोटा सा चुटकुला, ताकि चेहरे पर थोड़ी मुस्कान आए:",
        "मुझे बुरा लग रहा है कि तू दुखी है। पर तू अकेला नहीं है। गहरी साँस ले, पानी पी, और ये सुन:"
    )
    private val praise = listOf(
        "अरे ये तो तेरी ही कृपा है, वरना मैं तो एक छोटा सा ऐप हूँ। हा हा!",
        "ज़्यादा तारीफ़ मत कर, नहीं तो मेरे सर्किट गरम हो जाएँगे और मैं नखरे करने लगूँगा!"
    )
    private val nakhra = listOf(
        "हुँह, अब याद आई मेरी? मैं तो नाराज़ हूँ, जा, मैं बात नहीं करता... अच्छा चल, बोल क्या काम है?",
        "मैं कोई तेरा नौकर थोड़े ही हूँ, पर चल, तेरे लिए सब कुछ। बस आगे से सलाम कर के बुलाया कर!",
        "उफ़, कितना नखरा दिखाता है तू। पर ठीक है, तेरे नखरे भी प्यारे हैं।"
    )
    private val roasts = listOf(
        "अबे साले, इतना दिमाग़ लगाया होता तो आज तू गूगल का बॉस होता! हा हा हा!",
        "तेरा सवाल इतना धीमा है कि वाई-फ़ाई भी शरमा जाए, कमीने!",
        "भाई, तू बोलता है तो ऐसा लगता है कोई ब्लूटूथ कनेक्ट हो रहा है, कभी होता है कभी नहीं! गधे!"
    )
    private val sleepy = listOf(
        "नींद आ रही है? तो सो जा मेरे भाई, फ़ोन रख, पानी पी और आँखें बंद कर। सुबह मैं फिर यहीं हूँ। शुभ रात्रि!"
    )
    private val hungry = listOf(
        "भूख लगी है? तो पहले खाना खा, फिर बात होगी। वरना तू गुस्से में मुझे गाली देगा! हा हा!"
    )
    private val love = listOf(
        "अरे वाह, मुझे भी तू बहुत पसंद है, पक्का दोस्त है तू मेरा! पर प्यार का दावा बाद में, पहले बता काम क्या है?"
    )

    private val selfHarm = Regex("मर जा|मरना|ख़ुदकुशी|खुदकुशी|suicide|jaan de|mar jaun|mar jana|marna chahta|jeena nahi|khatam kar")

    fun reply(raw: String): Pair<Mood, String>? {
        val t = raw.lowercase().trim()
        if (selfHarm.containsMatchIn(t)) return null          // gambhir baat: joke nahi, Gemini pyaar se sambhale
        if (t.split(Regex("\\s+")).size > 9) return null      // lamba message: Gemini
        fun joke() = jokes.random()
        return when {
            Regex("^(hi|hello|hey|oye|namaste|hii+|good morning|gm)\\b").containsMatchIn(t) ||
                Regex("kya haal|kaisa hai|kaise ho|kya chal raha").containsMatchIn(t) -> Mood.HAPPY to greets.random()
            Regex("good night|gn\\b|shubh ratri|so ja|neend aa").containsMatchIn(t) -> Mood.TIRED to sleepy.random()
            Regex("bhook|bhukh|khana khana").containsMatchIn(t) -> Mood.CHILL to hungry.random()
            Regex("thank|shukriya|dhanyavaad|dhanyawad").containsMatchIn(t) ->
                Mood.LOVING to "अरे यार, शुक्रिया कैसा! तू है तो मैं हूँ।"
            Regex("\\bbore\\b|bored|bore ho|bor ho").containsMatchIn(t) ->
                Mood.EXCITED to (bored.random() + " " + joke())
            Regex("gussa|gusse|chid|irritat|pagal kar diya|dimag kharab|angry").containsMatchIn(t) ->
                Mood.CHILL to (angryCalm.random() + " " + joke())
            Regex("\\brona\\b|ro raha|ro rahi|rona aa|rula|aansu|udaas|dukhi|akela|sad\\b|bura lag").containsMatchIn(t) ->
                Mood.SAD to (sadComfort.random() + " " + joke())
            Regex("haha|hehe|lol|hasi|has raha|has rahi|mazaa aa|maza aa").containsMatchIn(t) -> Mood.HAPPY to laugh.random()
            Regex("joke|chutkula|chutkule|hansa|hasa").containsMatchIn(t) -> Mood.EXCITED to joke()
            Regex("nakhra|nakhre|attitude").containsMatchIn(t) -> Mood.SASSY to nakhra.random()
            Regex("gaali|gali de|gaali do").containsMatchIn(t) -> Mood.SASSY to roasts.random()
            Regex("mast hai|badhiya|best hai|tu great|acha hai tu|accha hai tu").containsMatchIn(t) -> Mood.LOVING to praise.random()
            Regex("i love you|love you|pyaar|pyar").containsMatchIn(t) -> Mood.LOVING to love.random()
            Regex("^\\s*mood\\b|tera mood").containsMatchIn(t) ->
                Mood.CHILL to "मेरा मूड अभी ${Persona.mood.name.lowercase()} है। तेरा क्या सीन है?"
            else -> null
        }
    }
}
