package com.jarvis.app

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Chhoti, saaf aur narm awaazein (ToneGenerator ke kharab beep ki jagah).
 * Khud banayi hui sine-wave chime: smooth attack + decay, taaki click/pop na aaye.
 */
object Fx {
    private const val RATE = 22050

    private fun play(notes: List<Triple<Double, Int, Int>>, gain: Float) {
        // notes: (frequency Hz, start ms, length ms)
        val total = notes.maxOf { it.second + it.third } + 120
        val n = RATE * total / 1000
        val pcm = ShortArray(n)
        for ((f, startMs, lenMs) in notes) {
            val s0 = RATE * startMs / 1000
            val len = RATE * lenMs / 1000
            for (i in 0 until len) {
                val t = i.toDouble() / RATE
                val attack = minOf(1.0, i / (RATE * 0.012))
                val decay = exp(-t * (3600.0 / lenMs))
                val v = (sin(2 * PI * f * t) * 0.7 + sin(4 * PI * f * t) * 0.18) * attack * decay
                val idx = s0 + i
                if (idx < n) pcm[idx] = (pcm[idx] + (v * 9000 * gain)).toInt().coerceIn(-30000, 30000).toShort()
            }
        }
        Thread {
            try {
                val track = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(pcm.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC).build()
                track.write(pcm, 0, pcm.size)
                track.play()
                Thread.sleep(total.toLong() + 100)
                track.release()
            } catch (_: Exception) { }
        }.start()
    }

    /** App / monster khulne ki awaaz: upar chadhti teen narm notes. */
    fun openChime() = play(listOf(Triple(523.25, 0, 420), Triple(659.25, 140, 420), Triple(783.99, 280, 700)), 1f)

    /** Settings toggle ki halki tick. */
    fun tick() = play(listOf(Triple(880.0, 0, 90)), 0.6f)
}
