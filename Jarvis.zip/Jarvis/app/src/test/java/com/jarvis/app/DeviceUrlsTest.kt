package com.jarvis.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DeviceUrlsTest {
    @Test fun youtubeSearchEncodes() {
        assertEquals("https://www.youtube.com/results?search_query=arijit+singh", DeviceUrls.youtubeSearch("arijit singh"))
    }

    @Test fun googleSearchEncodes() {
        assertEquals("https://www.google.com/search?q=python+tutorial", DeviceUrls.googleSearch("python tutorial"))
    }

    @Test fun luckyUsesBtnI() {
        assertTrue(DeviceUrls.youtubeLucky("kesariya").contains("btnI=1"))
    }

    @Test fun playStoreUrl() {
        assertEquals("https://play.google.com/store/search?c=apps&q=pubg", DeviceUrls.playStore("pubg"))
    }

    @Test fun normalizeAddsHttps() {
        assertEquals("https://example.com/a", DeviceUrls.normalize("example.com/a"))
        assertEquals("http://example.com", DeviceUrls.normalize("http://example.com"))
        assertEquals("https://example.com", DeviceUrls.normalize("example.com."))
    }
}

class PromptLengthTest {
    @Test fun wordCountIsParsed() {
        val (idea, n) = CommandRouter.parseLength("ek cyberpunk shehar 200 word")
        assertEquals(200, n)
        assertEquals("ek cyberpunk shehar", idea)
    }

    @Test fun lambaMeansLonger() {
        assertTrue(CommandRouter.parseLength("bahut lamba dragon ka prompt").second > CommandRouter.parseLength("lamba dragon").second)
    }

    @Test fun freeMovieSearchUsesLegalSites() {
        val u = DeviceUrls.freeMovies("inception")
        assertTrue(u.contains("tubitv.com"))
        assertTrue(!u.contains("torrent"))
    }
}
